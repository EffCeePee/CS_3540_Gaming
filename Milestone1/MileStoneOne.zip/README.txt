F. Colton Parry
Milestone 1
README.TXT

HOW TO PLAY:

Object: the goal is to destroy the rotating "Colton" enemy ships within 120sec.

hint: 1 in the middle, one in each corner of the universe.

Keyboard Instructions:

UP: up arrow
Down: down arrow
Left: left arrow
Right: right arrow
Rotate Right: 'e' key
Rotate Left: 'r' key
fire1: control key

WHAT I LEARNED:

So far I've leared three major things.  The first is that unity offers a lot of large powerful tools that can help speed things along if you know how to use it.  There are lots of built in functions and the documentation is pretty good for learing how to use the functions.   After going through several of the tutorials it made it a lot easier to add the functionality to my game and learn how to use the documentation.  The second thing that I've learned is that writing good games is hard. Coming up with a fun concept is where it starts, but that's not the end.  Making it look good and having good models is also very tough.  I can see why games cost so much to make and why having a series of games with resuable 3D renderings and graphics would be so appealing.  The thrid thing is that I like building the logic of the game, but not the graphics and artistic work.   I'd much rather make the game work using blocks than taking the time to render a 3d graphic, and while those are very important.  They just really aren't my forte.

